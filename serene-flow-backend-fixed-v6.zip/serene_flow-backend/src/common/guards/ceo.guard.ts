import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { isCeoEmail } from '../utils/ceo.util';

/**
 * Restricts a route to the single CEO/admin account (sereneflow27@gmail.com).
 * Identity is checked by email only — a stored or token `role` value is never trusted.
 */
@Injectable()
export class CeoRoleGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('User context missing');
    }

    if (!isCeoEmail(user.email)) {
      throw new ForbiddenException('Access restricted exclusively to CEO/Administrator account');
    }

    return true;
  }
}
