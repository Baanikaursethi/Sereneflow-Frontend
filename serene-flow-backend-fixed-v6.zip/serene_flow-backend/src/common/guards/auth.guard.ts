import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { FirebaseService } from '../../firebase';
import * as jwt from 'jsonwebtoken';
import { ConfigService } from '@nestjs/config';
import { roleForEmail } from '../utils/ceo.util';

@Injectable()
export class FirebaseAuthGuard implements CanActivate {
  constructor(
    private firebaseService: FirebaseService,
    private configService: ConfigService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('Missing or invalid Authorization header');
    }

    const token = authHeader.split('Bearer ')[1];
    if (!token) {
      throw new UnauthorizedException('Token not provided');
    }

    const firebaseAuth = this.firebaseService.auth;
    if (firebaseAuth) {
      try {
        const decodedToken = await firebaseAuth.verifyIdToken(token);
        request.user = {
          uid: decodedToken.uid,
          email: decodedToken.email || '',
          name: decodedToken.name || decodedToken.email?.split('@')[0],
          avatar: decodedToken.picture || null,
          // Role comes from the verified email ONLY — never from a token claim.
          role: roleForEmail(decodedToken.email),
          isVerified: decodedToken.email_verified ?? true,
        };
        return true;
      } catch (err) {
        // Fallback to local JWT token if Firebase token fails or in hybrid mode
      }
    }

    try {
      const secret = this.configService.get<string>('JWT_SECRET') || 'super-secret-serene-flow-jwt-key';
      const decoded: any = jwt.verify(token, secret);

      request.user = {
        uid: decoded.uid || decoded.sub,
        email: decoded.email,
        name: decoded.name || decoded.email?.split('@')[0],
        avatar: decoded.avatar || null,
        // Role comes from the email ONLY. A `role` claim inside an older token
        // (e.g. from a previous CEO account) is deliberately ignored.
        role: roleForEmail(decoded.email),
        isVerified: decoded.isVerified ?? true,
      };
      return true;
    } catch (e) {
      throw new UnauthorizedException('Invalid or expired authentication token');
    }
  }
}
