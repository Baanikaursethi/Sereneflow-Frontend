import { applyDecorators } from '@nestjs/common';
import { Transform } from 'class-transformer';
import { IsNotEmpty, registerDecorator, ValidationOptions } from 'class-validator';
import { isValidEmail, normalizeEmail } from '../utils/email.util';

/**
 * Lenient email check (see email.util.ts). No MX / mailbox-existence lookups.
 */
export function IsLenientEmail(validationOptions?: ValidationOptions) {
  return (object: object, propertyName: string) => {
    registerDecorator({
      name: 'isLenientEmail',
      target: object.constructor,
      propertyName,
      options: { message: 'Please enter a valid email address.', ...validationOptions },
      validator: {
        validate: (value: unknown) => isValidEmail(value),
      },
    });
  };
}

/**
 * Use on every DTO email field.
 *
 * The value is trimmed + lowercased BEFORE validation runs, so stray
 * whitespace from mobile keyboards / autofill / copy-paste ("  Jane@Gmail.com ")
 * no longer causes a valid address to be rejected, and every endpoint
 * sees the same canonical form.
 */
export function NormalizedEmail() {
  return applyDecorators(
    Transform(({ value }) => (typeof value === 'string' ? normalizeEmail(value) : value)),
    IsNotEmpty({ message: 'Email is required.' }),
    IsLenientEmail(),
  );
}
