// Fields that must NEVER be returned to a client, whoever is asking.
const SECRET_USER_FIELDS = [
  'password',
  'resetToken',
  'resetTokenExpiresAt',
  'resetAttempts',
  'verificationCode',
] as const;

/** Returns a copy of a stored user record with every secret field removed. */
export function stripUserSecrets<T extends Record<string, any>>(user: T | null | undefined): Record<string, any> {
  const copy: Record<string, any> = { ...(user || {}) };
  for (const field of SECRET_USER_FIELDS) delete copy[field];
  return copy;
}
