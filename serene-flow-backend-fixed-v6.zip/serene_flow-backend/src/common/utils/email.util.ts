// ============================================================
// EMAIL NORMALISATION + VALIDATION
//
// Deliberately lenient: this only checks that the value LOOKS like
// an email address (one "@", something before it, and a dotted
// domain after it). It never does MX / DNS / mailbox-existence
// lookups — whether a mailbox exists is proven by the verification
// code we email, not by rejecting addresses up front.
// ============================================================

const MAX_EMAIL_LENGTH = 254;
const MAX_LOCAL_LENGTH = 64;

/** Trim + lowercase. Non-strings become an empty string. */
export function normalizeEmail(value: unknown): string {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

export function isValidEmail(value: unknown): boolean {
  if (typeof value !== 'string') return false;

  const email = value.trim();
  if (email.length === 0 || email.length > MAX_EMAIL_LENGTH) return false;
  if (/\s/.test(email)) return false;

  const parts = email.split('@');
  if (parts.length !== 2) return false;
  const [local, domain] = parts;

  // Local part: present, not absurdly long, and no leading/trailing/double dots.
  if (!local || local.length > MAX_LOCAL_LENGTH) return false;
  if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;

  // Domain: at least two non-empty dot-separated labels, TLD of 2+ chars.
  if (!domain) return false;
  const labels = domain.split('.');
  if (labels.length < 2) return false;
  if (labels.some((label) => label.length === 0)) return false;
  if (labels[labels.length - 1].length < 2) return false;

  return true;
}
