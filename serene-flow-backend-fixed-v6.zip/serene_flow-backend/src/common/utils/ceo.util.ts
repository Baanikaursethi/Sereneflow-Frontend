// ============================================================
// CEO / MODERATOR IDENTITY
//
// The ONLY account with moderation powers (deleting other users'
// posts/replies, admin endpoints) is sereneflow27@gmail.com.
//
// Privilege is derived from the authenticated email address ONLY.
// It is deliberately NOT read from a stored `role` field, a JWT
// `role` claim, or an environment variable, so an old/stale CEO
// account (or a leftover role in the database) can never keep or
// regain moderation permissions.
// ============================================================

export const CEO_EMAIL = 'sereneflow27@gmail.com';

export function isCeoEmail(email?: string | null): boolean {
  return String(email ?? '').trim().toLowerCase() === CEO_EMAIL;
}

export function roleForEmail(email?: string | null): 'ceo' | 'user' {
  return isCeoEmail(email) ? 'ceo' : 'user';
}
