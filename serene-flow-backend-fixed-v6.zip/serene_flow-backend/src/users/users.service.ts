import { BadRequestException, Injectable, NotFoundException, Logger } from '@nestjs/common';
import { FirebaseService } from '../firebase';
import { UpdateProfileDto, UpdateAvatarDto } from './dto/update-profile.dto';
import { SpacesService } from '../spaces/spaces.service';
import { roleForEmail } from '../common/utils/ceo.util';
import { stripUserSecrets } from '../common/utils/user.util';

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(
    private firebaseService: FirebaseService,
    private spacesService: SpacesService,
  ) {}

  private async uploadBase64Image(base64Str: string, email: string): Promise<string> {
    const storage = this.firebaseService.storage;
    if (!storage) {
      this.logger.warn('Firebase Storage not initialized. Returning original string.');
      return base64Str;
    }

    // Check if it is a base64 data string
    const matches = base64Str.match(/^data:image\/([A-Za-z0-9+-]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      // If it's a URL or doesn't match base64 data pattern, return as is
      return base64Str;
    }

    const imageExtension = matches[1];
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, 'base64');

    // Keep profile photos comfortably below Firestore's document-size limit.
    // The frontend also resizes/compresses photos before sending them.
    if (buffer.length > 900 * 1024) {
      throw new BadRequestException('Profile photo is still too large after compression. Please choose a smaller image.');
    }

    try {
      const rawBucketName = this.firebaseService.app?.options.storageBucket;
      const bucketName = rawBucketName ? rawBucketName.replace(/^gs:\/\//, '') : undefined;
      const bucket = storage.bucket(bucketName);

      const filename = `avatars/${email.replace(/[@.]/g, '_')}_${Date.now()}.${imageExtension}`;
      const file = bucket.file(filename);

      await file.save(buffer, {
        metadata: {
          contentType: `image/${imageExtension}`,
        },
        public: true,
      });

      const publicUrl = `https://storage.googleapis.com/${bucket.name}/${filename}`;
      this.logger.log(`Avatar successfully uploaded to Firebase Storage: ${publicUrl}`);
      return publicUrl;
    } catch (error: any) {
      this.logger.error(`Error uploading avatar to Firebase Storage: ${error.message}`);
      if (error instanceof BadRequestException) throw error;
      throw new BadRequestException('Unable to upload profile photo. Please try again.');
    }
  }

  private getDocRefOrMemory(email: string) {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      return { firestore, ref: firestore.collection('users').doc(email) };
    }
    const users = this.firebaseService.getCollection('users');
    return { firestore: null, memoryUser: users.get(email), users };
  }

  async getProfile(userPayload: any) {
    const email = userPayload.email.toLowerCase();
    const firestore = this.firebaseService.firestore;
    let userData: any = null;

    if (firestore) {
      const doc = await firestore.collection('users').doc(email).get();
      if (doc.exists) {
        userData = doc.data();
      }
    } else {
      userData = this.firebaseService.getCollection('users').get(email);
    }

    if (!userData) {
      throw new NotFoundException('User profile not found');
    }

    // Calculate user stats
    let journalCount = 0;
    let moodCount = 0;
    let streak = 0;

    if (firestore) {
      const journalSnap = await firestore.collection('journals').where('userEmail', '==', email).get();
      journalCount = journalSnap.size;

      const moodSnap = await firestore.collection('moods').where('userEmail', '==', email).get();
      moodCount = moodSnap.size;
    } else {
      const journalsMap = this.firebaseService.getCollection('journals');
      journalCount = Array.from(journalsMap.values()).filter((j: any) => j.userEmail === email).length;

      const moodsMap = this.firebaseService.getCollection('moods');
      moodCount = Array.from(moodsMap.values()).filter((m: any) => m.userEmail === email).length;
    }

    // Calculate days using application
    const createdAt = new Date(userData.createdAt || Date.now());
    const daysActive = Math.max(1, Math.ceil((Date.now() - createdAt.getTime()) / (1000 * 60 * 60 * 24)));

    // Never return the password hash, verification code or reset code; the role is
    // always derived from the email address, not from whatever is stored.
    const publicProfile = stripUserSecrets(userData);

    return {
      ...publicProfile,
      role: roleForEmail(email),
      stats: {
        journalEntries: journalCount,
        moodCheckIns: moodCount,
        daysActive,
        streak: moodCount > 0 ? Math.min(moodCount, daysActive) : 0,
      },
    };
  }

  async updateProfile(userPayload: any, dto: UpdateProfileDto) {
    const email = userPayload.email.toLowerCase();
    const firestore = this.firebaseService.firestore;

    let avatarUrl = dto.avatar;
    if (dto.avatar) {
      avatarUrl = await this.uploadBase64Image(dto.avatar, email);
    }

    if (firestore) {
      const docRef = firestore.collection('users').doc(email);
      await docRef.update({
        ...(dto.name ? { name: dto.name } : {}),
        ...(avatarUrl !== undefined ? { avatar: avatarUrl } : {}),
      });
      const updated = await docRef.get();
      return { ...stripUserSecrets(updated.data()), role: roleForEmail(email) };
    } else {
      const users = this.firebaseService.getCollection('users');
      const user = users.get(email);
      if (!user) throw new NotFoundException('User not found');
      if (dto.name) user.name = dto.name;
      if (avatarUrl !== undefined) user.avatar = avatarUrl;
      users.set(email, user);
      return { ...stripUserSecrets(user), role: roleForEmail(email) };
    }
  }

  async updateAvatar(userPayload: any, dto: UpdateAvatarDto) {
    return this.updateProfile(userPayload, { avatar: dto.avatar });
  }

  async recordActivity(userPayload: any) {
    const email = userPayload.email.toLowerCase();
    const firestore = this.firebaseService.firestore;
    const now = new Date().toISOString();

    if (firestore) {
      await firestore.collection('users').doc(email).update({ lastActive: now });
    } else {
      const users = this.firebaseService.getCollection('users');
      const user = users.get(email);
      if (user) {
        user.lastActive = now;
        users.set(email, user);
      }
    }

    return { message: 'Last active status updated', lastActive: now };
  }

  /** Deletes every document in `collection` where `field == value`, in batches under Firestore's 500-write cap. */
  private async deleteWhere(collection: string, field: string, value: string): Promise<void> {
    const firestore = this.firebaseService.firestore!;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      const snap = await firestore.collection(collection).where(field, '==', value).limit(400).get();
      if (snap.empty) return;
      const batch = firestore.batch();
      snap.docs.forEach((doc) => batch.delete(doc.ref));
      await batch.commit();
    }
  }

  async deleteAccount(userPayload: any) {
    const email = userPayload.email.toLowerCase();
    const uid = userPayload.uid;
    const firestore = this.firebaseService.firestore;

    // Remove the user's Spaces footprint FIRST: their posts, their replies on other
    // people's posts, and their reactions (with the reaction counts recomputed).
    // Doing this before deleting the account record means a partial failure leaves the
    // account in place so the deletion can simply be retried.
    const spaces = await this.spacesService.purgeUserContent(email, uid);
    this.logger.log(
      `Account deletion for ${email}: removed ${spaces.postsDeleted} post(s), ${spaces.repliesRemoved} repl(ies) and ${spaces.reactionsRemoved} reaction(s) from Spaces.`,
    );

    if (firestore) {
      await this.deleteWhere('journals', 'userEmail', email);
      await this.deleteWhere('moods', 'userEmail', email);

      await firestore.collection('users').doc(email).delete();

      if (this.firebaseService.auth && uid) {
        try {
          await this.firebaseService.auth.deleteUser(uid);
        } catch {
          // ignore if already deleted
        }
      }
    } else {
      const journalsMap = this.firebaseService.getCollection('journals');
      Array.from(journalsMap.entries()).forEach(([k, v]: [string, any]) => {
        if (v.userEmail === email) journalsMap.delete(k);
      });

      const moodsMap = this.firebaseService.getCollection('moods');
      Array.from(moodsMap.entries()).forEach(([k, v]: [string, any]) => {
        if (v.userEmail === email) moodsMap.delete(k);
      });

      this.firebaseService.getCollection('users').delete(email);
    }

    return { message: 'Account and associated personal data deleted permanently.' };
  }
}
