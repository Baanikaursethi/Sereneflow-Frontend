import { Controller, Get } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AppService } from './app.service';
import { FirebaseService } from './firebase';

@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly configService: ConfigService,
    private readonly firebaseService: FirebaseService,
  ) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  /**
   * Safe diagnostics endpoint. It never returns secrets.
   * Used to verify that the deployed backend can reach Firestore
   * and that SMTP configuration is present.
   */
  @Get('health')
  async health() {
    const smtpConfigured = Boolean(
      this.configService.get<string>('SMTP_USER') &&
      this.configService.get<string>('SMTP_PASS'),
    );

    let firestore = 'not_initialized';
    let firestoreError: string | undefined;

    try {
      const db = this.firebaseService.firestore;
      if (!db) {
        firestore = 'not_initialized';
      } else {
        await db.collection('__health__').limit(1).get();
        firestore = 'ok';
      }
    } catch (error: any) {
      firestore = 'error';
      firestoreError = error?.message || 'Unknown Firestore error';
    }

    return {
      ok: firestore === 'ok' && smtpConfigured,
      firestore,
      ...(firestoreError ? { firestoreError } : {}),
      smtpConfigured,
      smtpUser: this.configService.get<string>('SMTP_USER') || null,
    };
  }
}
