import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { REACTION_TYPES } from '../reactions.util';

export class AddReactionDto {
  @ApiProperty({
    description:
      'The reaction to toggle for the calling user: one of the five Spaces reactions (❤️ I\'m here for you, 😊 I understand, 🌸 Stay strong, 💛 Sending care, 🌈 There\'s hope). Sending a reaction the user already holds removes it.',
    example: '❤️',
    enum: [...REACTION_TYPES],
  })
  @IsString()
  @IsNotEmpty()
  reactionType!: string;
}
