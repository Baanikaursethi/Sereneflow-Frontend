import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateReplyDto {
  @ApiProperty({ description: 'The updated reply text' })
  @IsString()
  @IsNotEmpty()
  text!: string;
}
