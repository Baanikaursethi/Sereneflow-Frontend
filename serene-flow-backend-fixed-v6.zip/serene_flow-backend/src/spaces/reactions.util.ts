// ============================================================
// SPACES REACTIONS — pure logic (no framework / database code)
//
// The five reaction types are EXACTLY the ones already used by the
// Spaces screen in the app (SpacesPage.tsx). They are keyed by emoji:
//
//   ❤️  "I'm here for you"
//   😊  "I understand"
//   🌸  "Stay strong"
//   💛  "Sending care"
//   🌈  "There's hope"
//
// Storage model (per post):
//   reactionUsers: { [emoji]: string[] }   who reacted — the source of truth
//   reactions:     { [emoji]: number }     counts derived from reactionUsers
//
// Users are identified by lowercased email. One user can hold each
// reaction type at most once; clicking it again removes just theirs.
// ============================================================

export const REACTION_TYPES = [
  '\u2764\uFE0F', // ❤️  I'm here for you
  '\u{1F60A}', //    😊  I understand
  '\u{1F338}', //    🌸  Stay strong
  '\u{1F49B}', //    💛  Sending care
  '\u{1F308}', //    🌈  There's hope
] as const;

export type ReactionType = (typeof REACTION_TYPES)[number];
export type ReactionUsers = Record<string, string[]>;
export type ReactionCounts = Record<string, number>;

// Variation selector-16 is optional in emoji sequences ("❤" vs "❤️"); ignore it when matching.
const stripVariation = (s: string) => s.replace(/\uFE0F/g, '').trim();
const CANONICAL = new Map<string, string>(REACTION_TYPES.map((r) => [stripVariation(r), r]));

const keyOf = (userKey: string) => String(userKey || '').trim().toLowerCase();

/** Maps client input onto one of the five canonical reaction keys, or null if it isn't one. */
export function canonicalReaction(input: unknown): string | null {
  if (typeof input !== 'string') return null;
  return CANONICAL.get(stripVariation(input)) ?? null;
}

/** Defensive read of whatever is stored: only known types, only unique non-empty string users. */
export function sanitizeReactionUsers(raw: unknown): ReactionUsers {
  const out: ReactionUsers = {};
  if (!raw || typeof raw !== 'object') return out;
  for (const type of REACTION_TYPES) {
    const list = (raw as any)[type];
    if (!Array.isArray(list)) continue;
    const seen = new Set<string>();
    for (const u of list) {
      const k = keyOf(u as string);
      if (k) seen.add(k);
    }
    if (seen.size > 0) out[type] = Array.from(seen);
  }
  return out;
}

/** Number of distinct users per reaction type. Always contains all five types. */
export function reactionCounts(raw: unknown): ReactionCounts {
  const users = sanitizeReactionUsers(raw);
  const counts: ReactionCounts = {};
  for (const type of REACTION_TYPES) counts[type] = users[type]?.length ?? 0;
  return counts;
}

/** The reaction types this user currently has on the post. */
export function reactionsForUser(raw: unknown, userKey: string): string[] {
  const users = sanitizeReactionUsers(raw);
  const k = keyOf(userKey);
  return REACTION_TYPES.filter((type) => (users[type] || []).includes(k));
}

/**
 * Toggle THIS user's reaction of `type`:
 *   - not selected yet  -> add them   (count goes up by 1)
 *   - already selected  -> remove them (count goes down by 1)
 * Everyone else's reactions are left untouched.
 */
export function toggleUserReaction(
  raw: unknown,
  type: string,
  userKey: string,
): { reactionUsers: ReactionUsers; active: boolean } {
  const users = sanitizeReactionUsers(raw);
  const k = keyOf(userKey);
  const current = users[type] || [];
  const has = current.includes(k);
  const next = has ? current.filter((u) => u !== k) : [...current, k];

  if (next.length > 0) users[type] = next;
  else delete users[type];

  return { reactionUsers: users, active: !has };
}

/** Removes every reaction held by any of the given identities. Reports how many were removed. */
export function removeUserFromReactions(
  raw: unknown,
  userKeys: Array<string | null | undefined>,
): { reactionUsers: ReactionUsers; removed: number } {
  const users = sanitizeReactionUsers(raw);
  const keys = new Set(userKeys.map((u) => keyOf(u as string)).filter(Boolean));
  let removed = 0;

  for (const type of Object.keys(users)) {
    const kept = users[type].filter((u) => !keys.has(u));
    removed += users[type].length - kept.length;
    if (kept.length > 0) users[type] = kept;
    else delete users[type];
  }
  return { reactionUsers: users, removed };
}
