// ============================================================
// SPACES CONTENT OWNERSHIP + ACCOUNT-DELETION CLEANUP — pure logic
// ============================================================
import { reactionCounts, removeUserFromReactions } from './reactions.util';

const lower = (v: unknown) => String(v ?? '').trim().toLowerCase();

/** True when a post/reply was written by the account identified by email and/or uid. */
export function isAuthoredBy(item: any, email?: string | null, uid?: string | null): boolean {
  const e = lower(email);
  const u = String(uid ?? '').trim();
  if (e && lower(item?.authorEmail) === e) return true;
  if (u && item?.authorUid && String(item.authorUid) === u) return true;
  return false;
}

export type PurgeResult =
  | { action: 'none' }
  | { action: 'delete'; repliesRemoved: number; reactionsRemoved: number }
  | {
      action: 'update';
      updates: { replies: any[]; reactionUsers: Record<string, string[]>; reactions: Record<string, number> };
      repliesRemoved: number;
      reactionsRemoved: number;
    };

/**
 * What to do with one post when an account is deleted:
 *  - their own post            -> delete it (its replies and reactions go with it)
 *  - someone else's post       -> drop their replies and reactions, and recompute the counts
 *  - nothing of theirs on it   -> leave it alone
 */
export function purgeUserFromPost(post: any, email?: string | null, uid?: string | null): PurgeResult {
  if (isAuthoredBy(post, email, uid)) {
    return { action: 'delete', repliesRemoved: 0, reactionsRemoved: 0 };
  }

  const replies: any[] = Array.isArray(post?.replies) ? post.replies : [];
  const keptReplies = replies.filter((r) => !isAuthoredBy(r, email, uid));
  const repliesRemoved = replies.length - keptReplies.length;

  const { reactionUsers, removed: reactionsRemoved } = removeUserFromReactions(post?.reactionUsers, [email, uid]);

  if (repliesRemoved === 0 && reactionsRemoved === 0) return { action: 'none' };

  return {
    action: 'update',
    updates: { replies: keptReplies, reactionUsers, reactions: reactionCounts(reactionUsers) },
    repliesRemoved,
    reactionsRemoved,
  };
}
