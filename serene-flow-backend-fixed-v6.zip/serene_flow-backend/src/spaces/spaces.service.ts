import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { FirebaseService } from '../firebase';
import { CreatePostDto, UpdatePostDto, AddReactionDto, AddReplyDto, UpdateReplyDto } from './dto';
import { ModerationService } from '../moderation';
import { isCeoEmail } from '../common/utils/ceo.util';
import { canonicalReaction, reactionCounts, reactionsForUser, toggleUserReaction } from './reactions.util';
import { isAuthoredBy, purgeUserFromPost } from './content.util';

interface Viewer {
  email: string;
  uid: string;
  isCeo: boolean;
}

interface Profile {
  name: string;
  avatar: string | null;
}

const lower = (v: unknown) => String(v ?? '').trim().toLowerCase();

@Injectable()
export class SpacesService {
  constructor(
    private firebaseService: FirebaseService,
    private moderationService: ModerationService,
  ) {}

  // ------------------------------------------------------------------
  // Identity + permissions
  //
  //  * Edit   — only the author of the post/reply.
  //  * Delete — the author, OR the CEO account (sereneflow27@gmail.com) only.
  //    The CEO check is by email; no stored/token "role" is trusted.
  // ------------------------------------------------------------------

  private viewerOf(userPayload: any): Viewer {
    const email = lower(userPayload?.email);
    if (!email) throw new UnauthorizedException('Authenticated user has no email address');
    return { email, uid: userPayload?.uid ? String(userPayload.uid) : '', isCeo: isCeoEmail(email) };
  }

  private isOwner(item: any, viewer: Viewer): boolean {
    return isAuthoredBy(item, viewer.email, viewer.uid);
  }

  // ------------------------------------------------------------------
  // Storage helpers (Firestore, or the in-memory fallback for local dev)
  // ------------------------------------------------------------------

  private async getRawPosts(): Promise<any[]> {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      const snap = await firestore.collection('posts').get();
      return snap.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
    }
    return Array.from(this.firebaseService.getCollection('posts').values());
  }

  private async getRawPost(id: string, notFoundMessage = 'Post not found'): Promise<any> {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      const doc = await firestore.collection('posts').doc(id).get();
      if (!doc.exists) throw new NotFoundException(notFoundMessage);
      return { ...doc.data(), id: doc.id };
    }
    const post = this.firebaseService.getCollection('posts').get(id);
    if (!post) throw new NotFoundException(notFoundMessage);
    return post;
  }

  private async savePost(post: any): Promise<void> {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      await firestore.collection('posts').doc(post.id).set(post);
    } else {
      this.firebaseService.getCollection('posts').set(post.id, post);
    }
  }

  private async removePost(id: string): Promise<void> {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      await firestore.collection('posts').doc(id).delete();
    } else {
      this.firebaseService.getCollection('posts').delete(id);
    }
  }

  /**
   * Atomic read-modify-write of one post. On Firestore this is a transaction, so two
   * people reacting/replying at the same moment can't overwrite each other's change.
   * `fn` receives the current post and returns the fields to update plus a result.
   */
  private async mutatePost<T>(
    id: string,
    fn: (post: any) => { updates?: Record<string, any>; result: T },
    notFoundMessage = 'Post not found',
  ): Promise<T> {
    const firestore = this.firebaseService.firestore;

    if (firestore) {
      const ref = firestore.collection('posts').doc(id);
      return firestore.runTransaction(async (tx) => {
        const snap = await tx.get(ref);
        if (!snap.exists) throw new NotFoundException(notFoundMessage);
        const { updates, result } = fn({ ...snap.data(), id });
        if (updates) tx.update(ref, updates);
        return result;
      });
    }

    const posts = this.firebaseService.getCollection('posts');
    const post = posts.get(id);
    if (!post) throw new NotFoundException(notFoundMessage);
    const { updates, result } = fn({ ...post });
    if (updates) posts.set(id, { ...post, ...updates });
    return result;
  }

  // ------------------------------------------------------------------
  // Author display: always the author's CURRENT username + profile picture
  // (unless the item was posted anonymously). Avatars are looked up at read
  // time, never copied into post/reply documents.
  // ------------------------------------------------------------------

  private async loadProfiles(emails: Iterable<string>): Promise<Map<string, Profile>> {
    const unique = Array.from(new Set(Array.from(emails).map(lower).filter(Boolean)));
    const profiles = new Map<string, Profile>();
    if (unique.length === 0) return profiles;

    const toProfile = (data: any): Profile => ({
      name: String(data?.name || data?.displayName || '').trim(),
      avatar: data?.avatar || null,
    });

    const firestore = this.firebaseService.firestore;
    if (firestore) {
      const CHUNK = 200;
      for (let i = 0; i < unique.length; i += CHUNK) {
        const slice = unique.slice(i, i + CHUNK);
        const snaps = await firestore.getAll(...slice.map((e) => firestore.collection('users').doc(e)));
        snaps.forEach((snap) => {
          if (snap.exists) profiles.set(lower(snap.id), toProfile(snap.data()));
        });
      }
    } else {
      const users = this.firebaseService.getCollection('users');
      for (const email of unique) {
        const data = users.get(email);
        if (data) profiles.set(email, toProfile(data));
      }
    }
    return profiles;
  }

  private profileEmailsOf(posts: any[]): string[] {
    const emails: string[] = [];
    for (const post of posts) {
      if (!post.anonymous) emails.push(lower(post.authorEmail));
      for (const reply of Array.isArray(post.replies) ? post.replies : []) {
        if (!reply.anonymous) emails.push(lower(reply.authorEmail));
      }
    }
    return emails.filter(Boolean);
  }

  /**
   * The shape sent to clients. Author emails / uids are NEVER included (that would
   * de-anonymise anonymous posts and expose everyone's address); instead the client gets
   * `isOwner` (is this the viewer's own content) and `authorIsCeo` (for the CEO badge).
   */
  private shapeReply(reply: any, viewer: Viewer, profiles: Map<string, Profile>) {
    const anonymous = !!reply.anonymous;
    const email = lower(reply.authorEmail);
    const live = profiles.get(email);
    const shaped: Record<string, any> = {
      id: reply.id,
      text: reply.text,
      time: reply.time,
      anonymous,
      authorName: anonymous ? null : live?.name || reply.authorName || null,
      authorAvatar: anonymous ? null : live?.avatar || null,
      authorIsCeo: !anonymous && isCeoEmail(email),
      isOwner: this.isOwner(reply, viewer),
    };
    if (reply.edited) shaped.edited = reply.edited;
    return shaped;
  }

  private shapePost(post: any, viewer: Viewer, profiles: Map<string, Profile>) {
    const anonymous = !!post.anonymous;
    const email = lower(post.authorEmail);
    const live = profiles.get(email);
    const replies = Array.isArray(post.replies) ? post.replies : [];
    const shaped: Record<string, any> = {
      id: post.id,
      text: post.text,
      time: post.time,
      anonymous,
      authorName: anonymous ? null : live?.name || post.authorName || null,
      authorAvatar: anonymous ? null : live?.avatar || null,
      authorIsCeo: !anonymous && isCeoEmail(email),
      isOwner: this.isOwner(post, viewer),
      reactions: reactionCounts(post.reactionUsers),
      myReactions: reactionsForUser(post.reactionUsers, viewer.email),
      replies: replies.map((r: any) => this.shapeReply(r, viewer, profiles)),
    };
    if (post.edited) shaped.edited = post.edited;
    return shaped;
  }

  private async shapeOne(post: any, viewer: Viewer) {
    const profiles = await this.loadProfiles([...this.profileEmailsOf([post]), viewer.email]);
    return this.shapePost(post, viewer, profiles);
  }

  // ------------------------------------------------------------------
  // Posts
  // ------------------------------------------------------------------

  async getPosts(userPayload: any) {
    const viewer = this.viewerOf(userPayload);
    const posts = await this.getRawPosts();
    const profiles = await this.loadProfiles(this.profileEmailsOf(posts));

    return posts
      .map((post) => this.shapePost(post, viewer, profiles))
      .sort((a: any, b: any) => new Date(b.time).getTime() - new Date(a.time).getTime());
  }

  async createPost(userPayload: any, dto: CreatePostDto) {
    // Content moderation check
    await this.moderationService.checkContent({ text: dto.text });

    const viewer = this.viewerOf(userPayload);
    const anonymous = !!dto.anonymous;
    const profiles = await this.loadProfiles([viewer.email]);
    const displayName = profiles.get(viewer.email)?.name || String(userPayload?.name || '').trim();
    const id = 'post_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

    const newPost = {
      id,
      text: dto.text,
      time: new Date().toISOString(),
      anonymous,
      authorName: anonymous ? null : displayName || null, // fallback snapshot only; live name wins on read
      authorEmail: viewer.email,
      authorUid: viewer.uid || null,
      reactions: reactionCounts({}),
      reactionUsers: {},
      replies: [],
    };

    await this.savePost(newPost);
    return this.shapePost(newPost, viewer, profiles);
  }

  async updatePost(userPayload: any, id: string, dto: UpdatePostDto) {
    await this.moderationService.checkContent({ text: dto.text });
    const viewer = this.viewerOf(userPayload);

    const updated = await this.mutatePost(
      id,
      (post) => {
        if (!this.isOwner(post, viewer)) {
          throw new ForbiddenException("You are not authorized to edit another user's post");
        }
        const updates = { text: dto.text, edited: new Date().toISOString() };
        return { updates, result: { ...post, ...updates } };
      },
      'Community post not found',
    );

    return this.shapeOne(updated, viewer);
  }

  async deletePost(userPayload: any, id: string) {
    const viewer = this.viewerOf(userPayload);
    const post = await this.getRawPost(id, 'Community post not found');

    // Own post, or the CEO account (email match only) moderating someone else's.
    if (!viewer.isCeo && !this.isOwner(post, viewer)) {
      throw new ForbiddenException('Only the post author or CEO/Admin can delete this community post');
    }

    await this.removePost(id);
    return { message: 'Community post deleted successfully', id };
  }

  // ------------------------------------------------------------------
  // Reactions — stored server-side, one entry per (user, reaction type)
  // ------------------------------------------------------------------

  async toggleReaction(userPayload: any, id: string, dto: AddReactionDto) {
    const viewer = this.viewerOf(userPayload);
    const type = canonicalReaction(dto.reactionType);
    if (!type) {
      throw new BadRequestException('Unknown reaction type');
    }

    return this.mutatePost(id, (post) => {
      const { reactionUsers, active } = toggleUserReaction(post.reactionUsers, type, viewer.email);
      const reactions = reactionCounts(reactionUsers);
      return {
        updates: { reactionUsers, reactions },
        result: {
          id,
          reactions,
          myReactions: reactionsForUser(reactionUsers, viewer.email),
          active,
        },
      };
    });
  }

  // ------------------------------------------------------------------
  // Replies
  // ------------------------------------------------------------------

  async addReply(userPayload: any, id: string, dto: AddReplyDto) {
    await this.moderationService.checkContent({ text: dto.text });

    const viewer = this.viewerOf(userPayload);
    const anonymous = !!dto.anonymous;
    const profiles = await this.loadProfiles([viewer.email]);
    const displayName = profiles.get(viewer.email)?.name || String(userPayload?.name || '').trim();

    const newReply = {
      id: 'rpl_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      text: dto.text,
      time: new Date().toISOString(),
      anonymous,
      authorName: anonymous ? null : displayName || null,
      authorEmail: viewer.email,
      authorUid: viewer.uid || null,
    };

    await this.mutatePost(id, (post) => ({
      updates: { replies: [...(Array.isArray(post.replies) ? post.replies : []), newReply] },
      result: null,
    }));

    return this.shapeReply(newReply, viewer, profiles);
  }

  async updateReply(userPayload: any, postId: string, replyId: string, dto: UpdateReplyDto) {
    await this.moderationService.checkContent({ text: dto.text });
    const viewer = this.viewerOf(userPayload);

    const updated = await this.mutatePost(postId, (post) => {
      const replies: any[] = Array.isArray(post.replies) ? [...post.replies] : [];
      const index = replies.findIndex((r) => r.id === replyId);
      if (index < 0) throw new NotFoundException('Reply not found');
      if (!this.isOwner(replies[index], viewer)) {
        throw new ForbiddenException("You are not authorized to edit another user's reply");
      }
      const reply = { ...replies[index], text: dto.text, edited: new Date().toISOString() };
      replies[index] = reply;
      return { updates: { replies }, result: reply };
    });

    const profiles = await this.loadProfiles([viewer.email]);
    return this.shapeReply(updated, viewer, profiles);
  }

  async deleteReply(userPayload: any, postId: string, replyId: string) {
    const viewer = this.viewerOf(userPayload);

    return this.mutatePost(postId, (post) => {
      const replies: any[] = Array.isArray(post.replies) ? [...post.replies] : [];
      const index = replies.findIndex((r) => r.id === replyId);
      if (index < 0) throw new NotFoundException('Reply not found');
      if (!viewer.isCeo && !this.isOwner(replies[index], viewer)) {
        throw new ForbiddenException('Only the reply author or CEO/Admin can delete this reply');
      }
      replies.splice(index, 1);
      return { updates: { replies }, result: { message: 'Reply deleted successfully', id: replyId } };
    });
  }

  async getReplies(userPayload: any, id: string) {
    const viewer = this.viewerOf(userPayload);
    const post = await this.getRawPost(id);
    const shaped = await this.shapeOne(post, viewer);
    return shaped.replies;
  }

  // ------------------------------------------------------------------
  // Account deletion: remove everything this user put into Spaces.
  //   - their posts (with the replies/reactions on them)
  //   - their replies on other people's posts
  //   - their reactions on other people's posts, with those counts recomputed
  // ------------------------------------------------------------------

  async purgeUserContent(email: string, uid?: string | null) {
    const summary = { postsDeleted: 0, repliesRemoved: 0, reactionsRemoved: 0 };
    const firestore = this.firebaseService.firestore;

    if (firestore) {
      const snap = await firestore.collection('posts').get();
      const toDelete: string[] = [];
      const toUpdate: string[] = [];

      for (const doc of snap.docs) {
        const result = purgeUserFromPost({ ...doc.data(), id: doc.id }, email, uid);
        if (result.action === 'delete') toDelete.push(doc.id);
        else if (result.action === 'update') toUpdate.push(doc.id);
      }

      // Delete their own posts in batches (Firestore caps a batch at 500 writes).
      for (let i = 0; i < toDelete.length; i += 400) {
        const batch = firestore.batch();
        toDelete.slice(i, i + 400).forEach((id) => batch.delete(firestore.collection('posts').doc(id)));
        await batch.commit();
      }
      summary.postsDeleted = toDelete.length;

      // Strip their replies/reactions from other posts, atomically per post.
      for (const id of toUpdate) {
        const ref = firestore.collection('posts').doc(id);
        await firestore.runTransaction(async (tx) => {
          const current = await tx.get(ref);
          if (!current.exists) return;
          const result = purgeUserFromPost({ ...current.data(), id }, email, uid);
          if (result.action === 'update') {
            tx.update(ref, result.updates);
            summary.repliesRemoved += result.repliesRemoved;
            summary.reactionsRemoved += result.reactionsRemoved;
          } else if (result.action === 'delete') {
            tx.delete(ref);
            summary.postsDeleted += 1;
          }
        });
      }
    } else {
      const posts = this.firebaseService.getCollection('posts');
      for (const [id, post] of Array.from(posts.entries())) {
        const result = purgeUserFromPost({ ...post, id }, email, uid);
        if (result.action === 'delete') {
          posts.delete(id);
          summary.postsDeleted += 1;
        } else if (result.action === 'update') {
          posts.set(id, { ...post, ...result.updates });
          summary.repliesRemoved += result.repliesRemoved;
          summary.reactionsRemoved += result.reactionsRemoved;
        }
      }
    }

    return summary;
  }
}
