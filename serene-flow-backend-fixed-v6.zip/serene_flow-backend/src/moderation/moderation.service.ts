import { BadRequestException, Injectable } from '@nestjs/common';
import { CheckContentDto } from './dto/check-content.dto';

// ============================================================
// SPACES CONTENT MODERATION
//
// This is the server-side gate: it is the ONLY check that actually
// matters, since any client-side check can be bypassed by calling the
// API directly. Every category the product requires guardrails for is
// covered here — sexual/explicit content, abusive/harassing content,
// hateful content, and threats — plus spam-link patterns as a general
// "violates community guidelines" catch-all.
//
// The message shown to the user is fixed and generic on purpose: it
// never echoes back which pattern matched, so it can't be used as an
// oracle to reverse-engineer the filter.
// ============================================================

export const COMMUNITY_GUIDELINES_MESSAGE =
  "This post can't be published because it goes against our Community Guidelines. Please revise your post and try again.";

@Injectable()
export class ModerationService {
  // 1. Sexually explicit / sexual content
  private readonly sexualPatterns: RegExp[] = [
    /\b(nude|naked)\s+(photo|pic|picture|video)s?\b/i,
    /\bsexting\b/i,
    /\bsend\s*nudes\b/i,
    /\bsexual(ly)?\s*explicit\b/i,
    /\bporn\w*\b/i,
    /\bxxx\b/i,
    /\b(dick|cock|pussy|vagina|penis)\s*(pic|pics|photo)s?\b/i,
    /\b(horny|fuck me|fuck you)\b/i,
    /\bnsfw\b/i,
  ];

  // 2. Abusive / harassing content (directed insults, degrading language)
  private readonly abusePatterns: RegExp[] = [
    /\byou'?re\s+(such\s+a\s+)?(a\s+)?(worthless|pathetic|disgusting|stupid|ugly|fat|loser|idiot|moron)\b/i,
    /\bshut\s*up\b.{0,15}\b(idiot|moron|loser|stupid)\b/i,
    /\b(idiot|moron|loser|scum|trash|garbage)\b.{0,15}\byou\b/i,
    /\bnobody\s+likes\s+you\b/i,
    /\bharass(ing|ment)?\b/i,
    /\bstalk(ing)?\s+you\b/i,
    /\b(go|get)\s+(kill|hurt)\s+yourself\b/i,
    /\bkys\b/i,
  ];

  // 3. Hateful content (slurs, hate speech, discrimination)
  private readonly hatePatterns: RegExp[] = [
    /\b(hate|slur|racist|racism|sexist|sexism|bigot\w*)\b/i,
    /\bi\s+hate\s+(all\s+)?(people|group|race|women|men|gays|jews|muslims|blacks|whites)\b/i,
    /\b(subhuman|inferior\s+race)\b/i,
  ];

  // 4. Threats of violence / harm to others
  private readonly threatPatterns: RegExp[] = [
    /\bi('?ll| will)\s+(kill|hurt|find|beat|stab|shoot)\s+you\b/i,
    /\byou\s+(should|will|are\s+going\s+to)\s+die\b/i,
    /\b(threat|threaten\w*)\s+(you|her|him|them)\b/i,
    /\bi('?m| am)\s+going\s+to\s+(kill|hurt|attack)\b/i,
    /\bwatch\s+your\s+back\b/i,
  ];

  // 5. Other guideline violations (spam / scam links)
  private readonly spamPatterns: RegExp[] = [
    /\bbuy\s*now\b.{0,15}\bclick\b/i,
    /\bfree\s*money\b.{0,15}\bclick\b/i,
    /\bwww\.\S+\.(xyz|click|loan)\b/i,
  ];

  private readonly forbiddenPatterns: RegExp[] = [
    ...this.sexualPatterns,
    ...this.abusePatterns,
    ...this.hatePatterns,
    ...this.threatPatterns,
    ...this.spamPatterns,
  ];

  async checkContent(dto: CheckContentDto) {
    const text = dto.text || '';

    for (const pattern of this.forbiddenPatterns) {
      if (pattern.test(text)) {
        throw new BadRequestException({
          approved: false,
          reason: COMMUNITY_GUIDELINES_MESSAGE,
          message: COMMUNITY_GUIDELINES_MESSAGE,
        });
      }
    }

    return {
      approved: true,
      reason: 'Content passes moderation checks.',
    };
  }
}
