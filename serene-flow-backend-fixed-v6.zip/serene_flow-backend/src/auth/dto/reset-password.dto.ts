import { IsNotEmpty, IsString, MinLength } from 'class-validator';
import { Transform } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { NormalizedEmail } from '../../common/decorators/normalized-email.decorator';

export class ResetPasswordDto {
  @ApiProperty({ description: 'The email address the reset code was sent to', example: 'user@example.com' })
  @NormalizedEmail()
  email!: string;

  @ApiProperty({ description: 'The 6-digit password reset code received via email', example: '654321' })
  @Transform(({ value }) => (typeof value === 'string' ? value.trim() : value))
  @IsString()
  @IsNotEmpty()
  token!: string;

  @ApiProperty({ description: 'The new password for the user account (min 6 characters)', example: 'newsecretpassword', minLength: 6 })
  @IsString()
  @MinLength(6, { message: 'New password must be at least 6 characters' })
  newPassword!: string;
}
