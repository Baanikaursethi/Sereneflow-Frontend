import { NormalizedEmail } from '../../common/decorators/normalized-email.decorator';
import { ApiProperty } from '@nestjs/swagger';

export class ForgotPasswordDto {
  @ApiProperty({ description: 'The email address of the user', example: 'user@example.com' })
  @NormalizedEmail()
  email!: string;
}
