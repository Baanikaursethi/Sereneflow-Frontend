import { IsNotEmpty, IsString } from 'class-validator';
import { NormalizedEmail } from '../../common/decorators/normalized-email.decorator';
import { ApiProperty } from '@nestjs/swagger';

export class LoginDto {
  @ApiProperty({ description: 'The email address of the user', example: 'user@example.com' })
  @NormalizedEmail()
  email!: string;

  @ApiProperty({ description: 'The password of the user', example: 'secretpassword' })
  @IsString()
  @IsNotEmpty()
  password!: string;
}
