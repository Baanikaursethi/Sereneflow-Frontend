import { IsNotEmpty, IsString } from 'class-validator';
import { NormalizedEmail } from '../../common/decorators/normalized-email.decorator';
import { ApiProperty } from '@nestjs/swagger';

export class VerifyEmailDto {
  @ApiProperty({ description: 'The email address of the user', example: 'user@example.com' })
  @NormalizedEmail()
  email!: string;

  @ApiProperty({ description: 'The verification code received via email', example: '654321' })
  @IsString()
  @IsNotEmpty()
  code!: string;
}

export class ResendVerificationDto {
  @ApiProperty({ description: 'The email address of the user', example: 'user@example.com' })
  @NormalizedEmail()
  email!: string;
}
