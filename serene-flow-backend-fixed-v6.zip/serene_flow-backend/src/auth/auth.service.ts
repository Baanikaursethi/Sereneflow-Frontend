import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { FirebaseService } from '../firebase';
import { SignupDto } from './dto/signup.dto';
import { LoginDto } from './dto/login.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { VerifyEmailDto, ResendVerificationDto } from './dto/verify-email.dto';
import { normalizeEmail } from '../common/utils/email.util';
import { roleForEmail } from '../common/utils/ceo.util';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import * as jwt from 'jsonwebtoken';
import * as nodemailer from 'nodemailer';

// Every authentication email (verification + password reset) is sent
// from, and authenticated as, this one Gmail account.
const AUTH_EMAIL_SENDER = 'sereneflow27@gmail.com';

const RESET_CODE_TTL_MS = 15 * 60 * 1000; // reset codes live for 15 minutes
const RESET_MAX_ATTEMPTS = 5; // wrong guesses before the code is burned

function escapeHtml(value: string): string {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Cryptographically-secure 6-digit numeric code (100000-999999). */
function generateCode(): string {
  return crypto.randomInt(100000, 1000000).toString();
}

/** Constant-time string comparison. */
function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(String(a));
  const bufB = Buffer.from(String(b));
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private firebaseService: FirebaseService,
    private configService: ConfigService,
  ) {}

  // ------------------------------------------------------------------
  // Email delivery
  // ------------------------------------------------------------------

  private async sendEmail(to: string, subject: string, html: string) {
    const smtpHost = this.configService.get<string>('SMTP_HOST') || 'smtp.gmail.com';
    const smtpPort = parseInt(this.configService.get<string>('SMTP_PORT') || '587', 10);
    const smtpUser = AUTH_EMAIL_SENDER;
    const smtpPass = (this.configService.get<string>('SMTP_PASS') || '').replace(/\s+/g, '');

    if (!smtpPass) {
      this.logger.error('SMTP_PASS is not configured; cannot send authentication emails.');
      throw new BadRequestException('Email service is not configured. Please try again later.');
    }

    const text = html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    const maxAttempts = 2; // one automatic retry for transient connection problems
    let lastError: any = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        // A fresh transport per attempt: no stale pooled connection can make
        // the first email after an idle period fail.
        const transporter = nodemailer.createTransport({
          host: smtpHost,
          port: smtpPort,
          secure: smtpPort === 465,
          auth: { user: smtpUser, pass: smtpPass },
          connectionTimeout: 15000,
          greetingTimeout: 15000,
          socketTimeout: 20000,
        });

        const info = await transporter.sendMail({
          from: `"Serene Flow" <${smtpUser}>`,
          to,
          subject,
          text,
          html,
        });

        this.logger.log(
          `Email accepted by SMTP server for ${to} from ${smtpUser} (attempt ${attempt}). messageId=${info.messageId || 'unknown'} response=${info.response || 'unknown'}`,
        );
        return;
      } catch (err: any) {
        lastError = err;
        // Never log SMTP credentials.
        this.logger.error(
          `SMTP email failure for ${to} (attempt ${attempt}/${maxAttempts}): code=${err?.code || 'unknown'} responseCode=${err?.responseCode || 'unknown'} message=${err?.message || 'unknown'}`,
        );
        // Bad credentials will not fix themselves on a retry.
        if (err?.code === 'EAUTH') break;
      }
    }

    this.logger.error(`Giving up sending email to ${to}`, lastError?.stack);
    throw new BadRequestException('We could not send the email right now. Please try again in a moment.');
  }

  // ------------------------------------------------------------------
  // Small persistence helpers (Firestore, or in-memory in local dev)
  // ------------------------------------------------------------------

  private async findUser(email: string): Promise<any | null> {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      const doc = await firestore.collection('users').doc(email).get();
      return doc.exists ? doc.data() : null;
    }
    return this.firebaseService.getCollection('users').get(email) ?? null;
  }

  private async updateUser(email: string, patch: Record<string, any>): Promise<void> {
    const firestore = this.firebaseService.firestore;
    if (firestore) {
      await firestore.collection('users').doc(email).update(patch);
      return;
    }
    const users = this.firebaseService.getCollection('users');
    const existing = users.get(email);
    if (existing) users.set(email, { ...existing, ...patch });
  }

  private generateToken(payload: object): string {
    const secret = this.configService.get<string>('JWT_SECRET') || 'super-secret-serene-flow-jwt-key';
    return jwt.sign(payload, secret, { expiresIn: '7d' });
  }

  /** What a client is allowed to know about an account. The role is always derived from the email. */
  private publicUser(user: any, overrides: Record<string, any> = {}) {
    return {
      uid: user.uid,
      email: user.email,
      name: user.name,
      avatar: user.avatar || null,
      role: roleForEmail(user.email),
      isVerified: !!user.isVerified,
      logins: user.logins || 0,
      createdAt: user.createdAt,
      lastActive: user.lastActive,
      ...overrides,
    };
  }

  // ------------------------------------------------------------------
  // Signup / verification
  // ------------------------------------------------------------------

  async signup(dto: SignupDto) {
    const email = normalizeEmail(dto.email);
    const firestore = this.firebaseService.firestore;
    const role = roleForEmail(email);
    const now = new Date().toISOString();

    const existingUser = await this.findUser(email);

    // A VERIFIED account really exists: refuse. An UNVERIFIED one means the
    // owner never finished (e.g. the email never arrived) — let them start over
    // instead of leaving them stuck with "already exists".
    if (existingUser && existingUser.isVerified) {
      throw new ConflictException('An account with this email address already exists.');
    }

    const hashedPassword = await bcrypt.hash(dto.password, 10);
    const verificationCode = generateCode();
    const uid = existingUser?.uid || 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

    let user: any;

    if (existingUser) {
      const patch = {
        name: dto.name,
        avatar: dto.avatar || existingUser.avatar || null,
        password: hashedPassword,
        verificationCode,
        role,
        lastActive: now,
      };
      await this.updateUser(email, patch);
      user = { ...existingUser, ...patch };

      if (firestore && this.firebaseService.auth) {
        try {
          await this.firebaseService.auth.updateUser(uid, { password: dto.password, displayName: dto.name });
        } catch {
          // Firebase Auth mirror is best-effort.
        }
      }
    } else {
      user = {
        uid,
        email,
        name: dto.name,
        avatar: dto.avatar || null,
        password: hashedPassword,
        isVerified: false,
        verificationCode,
        role,
        logins: 1,
        lastActive: now,
        createdAt: now,
      };

      if (firestore) {
        await firestore.collection('users').doc(email).set(user);
        // Also sync to Firebase Auth if initialized
        if (this.firebaseService.auth) {
          try {
            await this.firebaseService.auth.createUser({
              uid,
              email,
              password: dto.password,
              displayName: dto.name,
              emailVerified: false,
            });
          } catch (e) {
            // ignore sync duplicate error if exists
          }
        }
      } else {
        this.firebaseService.getCollection('users').set(email, user);
      }
    }

    // Send the first verification code automatically as part of signup.
    // If the mail server hiccups the account is still created; we tell the
    // client so it can prompt the user to tap "Resend Code" (which works).
    let emailSent = true;
    this.logger.log(`Sending initial verification email to ${email}`);
    try {
      await this.sendEmail(
        email,
        'Verify Your Serene Flow Account',
        `<h2>Welcome to Serene Flow, ${escapeHtml(dto.name)}!</h2><p>Your verification code is: <strong>${verificationCode}</strong></p>`,
      );
    } catch (err: any) {
      emailSent = false;
      this.logger.error(`Initial verification email to ${email} failed: ${err?.message || err}`);
    }

    const token = this.generateToken({ uid, email, name: dto.name, role, isVerified: false });

    return {
      message: emailSent
        ? 'Account created successfully. We sent a verification code to your email.'
        : 'Account created, but we could not send the verification email. Please tap "Resend Code".',
      emailSent,
      token,
      user: this.publicUser(user, { isVerified: false }),
    };
  }

  async login(dto: LoginDto) {
    const email = normalizeEmail(dto.email);
    const user = await this.findUser(email);

    if (!user) {
      throw new UnauthorizedException('Invalid email or password credentials');
    }

    const isMatch = await bcrypt.compare(dto.password, user.password);
    if (!isMatch) {
      throw new UnauthorizedException('Invalid email or password credentials');
    }

    // Update logins count and last active timestamp. The role is ALWAYS
    // recomputed from the email, and any stale stored role (e.g. an old CEO
    // account still flagged 'ceo') is corrected here.
    const role = roleForEmail(user.email || email);
    const logins = (user.logins || 0) + 1;
    const lastActive = new Date().toISOString();
    const patch: Record<string, any> = { logins, lastActive };
    if (user.role !== role) patch.role = role;
    await this.updateUser(email, patch);
    Object.assign(user, patch);

    const token = this.generateToken({
      uid: user.uid,
      email: user.email,
      name: user.name,
      role,
      isVerified: user.isVerified,
    });

    return {
      message: 'Logged in successfully',
      token,
      user: this.publicUser(user),
    };
  }

  async logout(userPayload: any) {
    return { message: 'Logged out successfully' };
  }

  async verifyEmail(dto: VerifyEmailDto) {
    const email = normalizeEmail(dto.email);
    const user = await this.findUser(email);

    if (!user) {
      throw new NotFoundException('Account not found');
    }

    if (!user.verificationCode || user.verificationCode !== dto.code.trim()) {
      throw new BadRequestException('Invalid verification code');
    }

    const role = roleForEmail(user.email || email);
    await this.updateUser(email, { isVerified: true, verificationCode: null, role });
    Object.assign(user, { isVerified: true, verificationCode: null, role });

    const token = this.generateToken({
      uid: user.uid,
      email: user.email,
      name: user.name,
      role,
      isVerified: true,
    });

    return {
      message: 'Email verified successfully',
      token,
      user: this.publicUser(user, { isVerified: true }),
    };
  }

  async resendVerification(dto: ResendVerificationDto) {
    const email = normalizeEmail(dto.email);
    const user = await this.findUser(email);

    if (!user) {
      throw new NotFoundException('User account not found');
    }

    if (user.isVerified) {
      return { message: 'Account email is already verified' };
    }

    const verificationCode = generateCode();
    await this.updateUser(email, { verificationCode });

    await this.sendEmail(
      email,
      'Resent Email Verification Code - Serene Flow',
      `<p>Your new verification code is: <strong>${verificationCode}</strong></p>`,
    );

    return { message: 'Verification email resent successfully' };
  }

  // ------------------------------------------------------------------
  // Forgot / reset password
  //
  // Flow:  POST /auth/forgot-password { email }
  //          -> a 6-digit code is stored on that account (field `resetToken`)
  //             with a 15-minute expiry and emailed to the address.
  //        POST /auth/reset-password { email, token, newPassword }
  //          -> the code must match THAT account's stored code, be unexpired,
  //             and not have been guessed wrong too many times.
  // ------------------------------------------------------------------

  async forgotPassword(dto: ForgotPasswordDto) {
    const email = normalizeEmail(dto.email);
    const neutral = { message: 'If an account with that email exists, a password reset code has been sent.' };

    const user = await this.findUser(email);
    if (!user) {
      // Neutral response so the endpoint does not reveal whether an account exists.
      return neutral;
    }

    const resetCode = generateCode();
    await this.updateUser(email, {
      resetToken: resetCode,
      resetTokenExpiresAt: new Date(Date.now() + RESET_CODE_TTL_MS).toISOString(),
      resetAttempts: 0,
    });

    await this.sendEmail(
      email,
      'Serene Flow - Reset Your Password',
      `<h2>Password Reset Request</h2><p>Your Serene Flow password reset code is: <strong>${resetCode}</strong></p><p>Enter this code in the app to choose a new password. It expires in 15 minutes.</p><p>If you did not request this, you can safely ignore this email.</p>`,
    );

    return neutral;
  }

  async resetPassword(dto: ResetPasswordDto) {
    const email = normalizeEmail(dto.email);
    const code = String(dto.token || '').trim();
    const invalid = () => new BadRequestException('Invalid or expired reset code.');

    const user = await this.findUser(email);
    if (!user || !user.resetToken) {
      throw invalid();
    }

    const clearCode = { resetToken: null, resetTokenExpiresAt: null, resetAttempts: 0 };

    const expiresAt = Date.parse(user.resetTokenExpiresAt || '');
    if (!Number.isFinite(expiresAt) || Date.now() > expiresAt) {
      await this.updateUser(email, clearCode);
      throw invalid();
    }

    const attempts = Number(user.resetAttempts || 0);
    if (attempts >= RESET_MAX_ATTEMPTS) {
      await this.updateUser(email, clearCode);
      throw new BadRequestException('Too many incorrect attempts. Please request a new reset code.');
    }

    if (!safeEqual(user.resetToken, code)) {
      await this.updateUser(email, { resetAttempts: attempts + 1 });
      throw invalid();
    }

    const hashedPassword = await bcrypt.hash(dto.newPassword, 10);
    await this.updateUser(email, { password: hashedPassword, ...clearCode });

    if (this.firebaseService.firestore && this.firebaseService.auth && user.uid) {
      try {
        await this.firebaseService.auth.updateUser(user.uid, { password: dto.newPassword });
      } catch {
        // Firebase Auth mirror is best-effort; the app authenticates against the users collection.
      }
    }

    return { message: 'Password updated successfully. You can now log in with your new password.' };
  }
}
