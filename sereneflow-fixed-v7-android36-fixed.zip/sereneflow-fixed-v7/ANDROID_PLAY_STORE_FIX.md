# Serene Flow Android 36 / 16 KB compatibility update

This copy upgrades the app from Expo SDK 51 / React Native 0.74 to Expo SDK 54 / React Native 0.81, which targets Android API 36 and includes React Native's 16 KB page-size support. It also increments Android `versionCode` to **10** because the Play Console screenshot shows version code 9.

## Build a new Android App Bundle (AAB)

1. Install Node.js **20.19.4 or newer**.
2. Open PowerShell in this project folder (`sereneflow-fixed-v7`).
3. Run:

   ```powershell
   npm install
   npx expo install --fix
   npx expo-doctor
   ```

4. Review any Expo Doctor warnings. Then install/use EAS CLI and sign in:

   ```powershell
   npm install --global eas-cli
   eas login
   eas build:configure
   ```

   If `eas build:configure` asks to edit `eas.json`, keep the production Android build type as `app-bundle`.

5. Build the AAB:

   ```powershell
   eas build --platform android --profile production
   ```

6. Download the resulting `.aab` from the EAS build page and upload it to Google Play Console. Confirm Play Console shows **target API 36** and no 16 KB memory page-size error before rolling out.

## Important notes

- The Android package name remains `com.sereneflow.app`.
- `versionCode` is now 10; do not lower it when creating later releases.
- Do not replace or reset the app's Play signing key. EAS may ask about Android credentials; use the existing production signing credentials if this app already has a release in Play Console. If you don't have them, stop and recover the correct credentials rather than creating a different app identity.
- SDK upgrades can expose UI or native-module compatibility issues. Test login, signup, password reset/email, Spaces, mood history, journal, profile image picker, and audio playback on a device before production rollout.
- The backend ZIP was not modified because neither Play Console error is fixed in the backend; these are Android frontend build/dependency issues.
- I cannot build or certify an AAB in this environment. The new AAB must be built and checked after installing the updated dependencies.
